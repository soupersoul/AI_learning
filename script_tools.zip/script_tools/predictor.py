"""
Predictor for ModelArts online service.
"""
from .client.api import *
from .model import *
from .config.auth import auth_by_APIG, auth_by_roma_api
from abc import ABCMeta, abstractmethod
from six import with_metaclass
from json import JSONEncoder
from .infers_api import InfersApi
from .util.config import Config
from .util.secret_util import auth_expired_handler


from io import BytesIO
from PIL import Image


class Predictor(object):
    """
    A ModelArts Predictor that can be predicted, got service information and list,
    changed service state and configuration.
    """
    def __init__(self, session, service_id, is_local=False):
        """
        Initialize a Predictor, determine the predictor authorize type.
        param session: Building interactions with HUAWEI Cloud service.
        param service_id: The deployed model service id
        param is local: local service flag
        """
        self.session = session
        self.service_id = service_id
        self.is_local = is_local
        if self.session.auth == constant.AKSK_AUTH:
            self.predictor_instance = PredictorApiAKSKImpl(self.session, service_id)
        elif session.auth == constant.ROMA_AUTH:
            self.predictor_instance = PredictorApiROMAImpl(self.session, service_id)
        else:
            self.predictor_instance = PredictorApiAccountImpl(self.session, service_id)

        if not self.is_local:
            service_info = self.get_service_info(service_id=self.service_id)
            self.__set_service_attribute(service_params=service_info)

    def get_service_info(self, service_id=None):
        """ Get the deployed model service information
        :param service_id: The deployed model service id
        :return: The deployed service information,including model service access address.
        """
        return self.predictor_instance.get_service_info(service_id)

    def __set_service_attribute(self, service_params):
        """ set model attribute, model parameters
        :param service_params: service params
        """
        def get_value(service_params, params):
            return service_params[params] if params in service_params else None

        self.status = get_value(service_params, 'status')
        self.is_shared = get_value(service_params, 'is_shared')
        self.failed_times = get_value(service_params, 'failed_times')
        self.description = get_value(service_params, 'description')
        self.service_name = get_value(service_params, 'service_name')
        self.project = get_value(service_params, 'project')
        self.invocation_times = get_value(service_params, 'invocation_times')
        self.progress = get_value(service_params, 'progress')
        self.publish_at = get_value(service_params, 'publish_at')
        self.owner = get_value(service_params, 'owner')
        self.service_id = get_value(service_params, 'service_id')
        self.tenant = get_value(service_params, 'tenant')
        self.infer_type = get_value(service_params, 'infer_type')

    def predict(self, data, data_type):
        """ service predict
        :param data:  Input data for which you want the model to provide inference.
        :param data_type: support {files, images}
        :return: predict result
        """
        if data_type not in Config.getenv("PREDICTOR_DATA_TYPE_SET"):
            raise Exception("The data type %s is not in %s" % (data_type, Config.getenv("PREDICTOR_DATA_TYPE_SET")))

        if self.is_local:
            local_service_host = "http://{host}:{port}".format(host=Config.getenv("MODEL_LOCAL_HOST"),
                                                               port=Config.getenv("MODEL_LOCAL_INFER_PORT"))
            if data_type == constant.JSON_TYPE:
                headers = {'Content-Type': 'application/json'}
                data = open(data, mode='r')
                content = data.read()
                body = json.loads(content, encoding='utf-8')
                predict_result = requests.post(url=local_service_host, headers=headers, data=json.dumps(body),
                                               proxies={"http": None, "https": None})
            else:
                #data = {data_type: (data, open(data, 'rb'))}
                f = BytesIO()
                data.save(f, format='PNG')
                data = f.getvalue()
                file_path = '1.jpg'  # 随便取一个文件名都可以
                data = {data_type: (file_path, data)}
                predict_result = requests.post(local_service_host, files=data, proxies={"http": None, "https": None})
            return predict_result.text

        return self.predictor_instance.predict(data, data_type)

    @classmethod
    def local_predict(cls, data, data_type):
        """ local predict
        :param data: Input data for which you want the model to provide inference.
        :param data_type: images and files
        :return: predict result
        """
        if data_type not in Config.getenv("PREDICTOR_DATA_TYPE_SET"):
            raise Exception("The data type %s is not in %s" % (data_type, Config.getenv("PREDICTOR_DATA_TYPE_SET")))

        local_service_host = "http://{host}:{port}".format(host=Config.getenv("MODEL_LOCAL_HOST"),
                                                           port=Config.getenv("MODEL_LOCAL_INFER_PORT"))
        if data_type == constant.JSON_TYPE:
            headers = {'Content-Type': 'application/json'}
            data = open(data, mode='r')
            content = data.read()
            body = json.loads(content, encoding='utf-8')
            predict_result = requests.post(url=local_service_host, headers=headers, data=json.dumps(body),
                                           proxies={"http": None, "https": None})
        else:
            data = {data_type: (data, open(data, 'rb'))}
            predict_result = requests.post(local_service_host, files=data, proxies={"http": None, "https": None})
        return predict_result.text

    @classmethod
    def get_service_list(cls, session, **kwargs):
        """ Get the current account services, and return service information(dict type)
        :param session: session with HUAWEI cloud service
        :param kwargs: index params
        :return:  service list
        """
        service_id = None
        if session.auth == constant.AKSK_AUTH:
            predictor_instance = PredictorApiAKSKImpl(session, service_id)
        elif session.auth == constant.ROMA_AUTH:
            predictor_instance = PredictorApiROMAImpl(session, service_id)
        else:
            predictor_instance = PredictorApiAccountImpl(session, service_id)

        return predictor_instance.get_service_list(**kwargs)

    @classmethod
    def get_service_object_list(cls, session, is_show=True, **kwargs):
        """ Get the current account services, and return service object(Predictor)
        :param session: session with HUAWEI cloud service
        :param is_show: show in console
        :param kwargs: index params
        :return: service list
        """
        index_surplus_set = set(kwargs.keys()) - constant.SERVICE_INDEX_PARAMS
        if len(index_surplus_set) != 0:
            raise ValueError('The input params: %s for service index is surplus' % index_surplus_set)
        service_object_list = []
        service_list_info = Predictor.get_service_list(session, **kwargs)

        for one_predictor in service_list_info['services']:
            service_object_list.append(Predictor(session, one_predictor['service_id']))
        if is_show:
            print(json.dumps(service_list_info, indent=1))
        return service_object_list

    @classmethod
    def get_service_by_id(cls, session, service_id):
        """ return model object of model_id
        :param session: session with HUAWEI cloud service
        :param service_id: service id
        """
        return Predictor(session, service_id)

    @classmethod
    def delete_service_by_id(cls, session, service_id):
        """ delete service object by service_id
        :param session: session with HUAWEI cloud service
        :param service_id: service id
        """
        service_instance = Predictor(session, service_id)
        service_instance.delete_service(service_id=service_id)

    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        return self.predictor_instance.change_edge_service_state(node_id, action_body, service_id=service_id)

    def update_service_config(self, service_id=None, **config_body):
        """ update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        return self.predictor_instance.update_service_config(service_id=service_id, **config_body)

    def get_service_monitor(self, service_id=None, node_id=None):
        """ service monitor information
            Args: service_id: service id
            Args: node_id: node id
            return: monitor information
        """
        return self.predictor_instance.get_service_monitor(service_id=service_id, node_id=node_id)

    def get_service_logs(self):
        """
        :return:  monitor information
        """
        return self.predictor_instance.get_service_logs(service_id=self.service_id)

    def delete_service(self, service_id=None):
        """
        :param service_id: service id
        """
        if service_id is None:
            service_id = self.service_id
        self.predictor_instance.delete_service(service_id=service_id)
        print("Successfully delete the service %s ." % service_id)


class PredictorApiBase(with_metaclass(ABCMeta, object)):
    """ Make prediction requests to a ModelArts model service endpoint
        """

    def __init__(self):
        """ Initialize Predictor
            service_id: The deployed model service id
        """

    @abstractmethod
    def get_service_info(self):
        """ Get the deployed model service information
        return: The deployed service information,including model service access address.
        """
        pass

    @abstractmethod
    def predict(self, data, data_type):
        """
        :param data:  Input data for which you want the model to provide inference.
        :param data_type: {files, images}
        return: predict result
        """
        pass

    @abstractmethod
    def get_service_list(self):
        """
        return User service list
        """
        pass

    @abstractmethod
    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """ change a service state.
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        pass

    @abstractmethod
    def update_service_config(self, service_id=None, **config_body):
        """ update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return Service update configuration tasks result.
        """
        pass

    @abstractmethod
    def get_service_monitor(self, service_id=None):
        """ service monitor information
        :param service_id: service id
        :return: monitor information
        """
        pass

    @abstractmethod
    def get_service_logs(self, service_id=None):
        """ service logs
        :param service_id: service id
        :return: monitor information
        """
        pass

    @abstractmethod
    def delete_service(self, service_id):
        """
        :param service_id: service id
        :return: delete service endpoint
        """
        pass

    @staticmethod
    def convert_config_format(config_body):
        """  convert config parameter format to dict
        :param config_body: configuration body
        """
        config_value = []
        for service_config in config_body:
            one_config = dict()
            one_config['model_id'] = service_config.model_id
            one_config['specification'] = service_config.specification
            one_config['instance_count'] = service_config.instance_count
            if service_config.envs is not None:
                one_config['envs'] = service_config.envs
            config_value.append(one_config)

        return config_value


class PredictorApiAccountImpl(PredictorApiBase):
    """ Make prediction requests to a ModelArts model service endpoint
    """

    def __init__(self, session, service_id):
        """ Initialize Predictor
        :param session: Building interactions with HUAWEI Cloud Service, including project id.
        :param service_id: The deployed model service id
        """
        PredictorApiBase.__init__(self)
        self.session = session
        self.service_id = service_id
        self.service_api = ServiceApi(session.client)
        self.service_info = None

    def get_service_info(self, service_id=None):
        """ Get the deployed model service information
        :param service_id: service id
        """
        def convert_object_to_dict(model_info_resp):
            convert_dict_name = self.revert_dict_key(model_info_resp)
            if 'config' in convert_dict_name:
                for id in range(len(convert_dict_name['config'])):
                    convert_dict_name['config'][id] = self.revert_dict_key(
                        convert_dict_name['config'][id].__dict__)
            return convert_dict_name

        if service_id is None:
            service_id = self.service_id

        service_info_resp = self.service_api.get_service_info(self.session.project_id, service_id)
        return convert_object_to_dict(service_info_resp.__dict__)

    def predict(self, data, data_type):
        """
        :param data:  Input data for which you want the model to provide inference.
        :param data_type: support {files,images}
        :return: predict result
        """
        session_configuration_host = self.session.client.configuration.host

        self.service_info = self.get_service_info()
        self.session.client.configuration.host = self.service_info['access_address']
        try:
            infers_file_api = InfersApi(self.session.client)
            infer_file_result = infers_file_api.service_model_reasoning(data=data, data_type=data_type)
        except Exception as e:
            self.session.client.configuration.host = session_configuration_host
            raise Exception(e)
        self.session.client.configuration.host = session_configuration_host
        return infer_file_result

    def get_service_list(self, **kwargs):
        """
        :param kwargs: index params
        :return: User service list
        """
        service_list_resp = self.service_api.get_service_list(project_id=self.session.project_id, **kwargs)
        service_list_resp_dict = dict()
        service_list_resp_dict['count'] = service_list_resp.count
        if service_list_resp.count > 0:
            service_list_resp_dict['services'] = []
            for service in service_list_resp.services:
                service_list_resp_dict['services'].append(self.revert_dict_key(service.__dict__))

        return service_list_resp_dict

    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """ change a service state.
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        if service_id is None:
            service_id = self.service_id

        return self.service_api.operate_a_service(self.session.project_id, service_id, node_id, action_body)

    def update_service_config(self, service_id=None, **config_body):
        """ update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        service_config_body = config_body

        if 'configs' in config_body:
            service_config_body['config'] = PredictorApiBase.convert_config_format(
                config_body['configs'])

        if service_id is None:
            service_id = self.service_id

        return self.service_api.update_service_config(self.session.project_id, service_id, service_config_body)

    def get_service_monitor(self, service_id=None, node_id=None):
        """ service monitor information
        :param service_id: service id
        :param node_id: node id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        return self.service_api.get_service_monitor(self.session.project_id, service_id)

    def get_service_logs(self, service_id=None):
        """ service logs
        :param service_id: service  id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        return self.service_api.get_service_logs(self.session.project_id, service_id)

    def delete_service(self, service_id):
        """ Only delete model endpoint
        :param service_id: service id
        """
        self.service_api.delete_micro_service(project_id=self.session.project_id, service_id=service_id)

    @staticmethod
    def revert_dict_key(dict_name):
        """convert dict "_key" to "key" and delete value or len(list) is none
        :param dict_name: dict
        :return: dict
        """
        temp_dict_name = dict()
        for idx, val in dict_name.items():
            if val is None or (type(val) is list and len(val) == 0):
                continue
            temp_dict_name[idx.strip('_')] = val
        return temp_dict_name


class PredictorApiAKSKImpl(PredictorApiBase):
    """ Make prediction requests to a ModelArts model service endpoint
    """

    def __init__(self, session, service_id):
        """ Initialize Predictor
        :param session: Building interactions with HUAWEI Cloud Service, including project id.
        :param service_id: The deployed model service id
        """
        PredictorApiBase.__init__(self)
        self.session = session
        self.service_id = service_id
        self.base_request_url = '/v1/' + self.session.project_id + '/services/'

    @auth_expired_handler
    def get_service_info(self, service_id=None):
        """
        :param service_id: service id
        :return: service information
        """
        if service_id is None:
            service_id = self.service_id
        request_url = self.base_request_url + service_id
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url, '')

    @auth_expired_handler
    def predict(self, data, data_type):
        """
        :param data: Input data for which you want the model to provide inference.
        :param data_type: support {files, images}
        :return: predict result
        """
        access_address = self.get_service_info()["access_address"]
        access_host = access_address.split("//")[1].split('/', 1)[0]
        access_request = '/' + access_address.split("//")[1].split('/', 1)[1]

        if 'JSON' == data_type.upper() and type(data) != str:
            headers = {'Content-Type': "application/json"}
            predict_body = json.dumps(data)
        else:
            predict_file = {data_type: open(data, 'rb')}
            predict_body, content_type = requests.models.RequestEncodingMixin._encode_files(predict_file, {})
            headers = {'content-type': content_type}
            predict_file[data_type].close()

        predict_result = auth_by_APIG(self.session.access_key, self.session.secret_key, 'POST', access_host,
                                      access_request, '', body=predict_body, headers=headers)
        return predict_result

    @auth_expired_handler
    def get_service_list(self, **kwargs):
        """
        :param kwargs: index params
        :return: User service list
        """
        request_url = '/v1/' + self.session.project_id + '/services'
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url,
                            query=kwargs)

    @auth_expired_handler
    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id + '/nodes/' + node_id + '/status'
        action_body = JSONEncoder().encode(action_body)
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'PUT', self.session.host, request_url, '',
                            action_body)

    @auth_expired_handler
    def update_service_config(self, service_id=None, **config_body):
        """update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        service_config_body = config_body
        if 'configs' in config_body:
            service_config_body['config'] = PredictorApiBase.convert_config_format(
                config_body['configs'])

        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id
        service_config_body = JSONEncoder().encode(service_config_body)
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'PUT',
                            self.session.host, request_url, '', service_config_body)

    @auth_expired_handler
    def get_service_monitor(self, service_id=None, node_id=None):
        """  service monitor information
        :param service_id: service id
        :param node_id: node id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        query = {}
        if node_id:
            query['node_id'] = node_id
        request_url = self.base_request_url + service_id + '/monitor'
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url,
                            query)

    @auth_expired_handler
    def get_service_logs(self, service_id=None):
        """
        :param service_id:  service id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id + '/logs'
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url, '')

    @auth_expired_handler
    def delete_service(self, service_id):
        """ Delete a service
        :param service_id: service id
        """
        request_url = '/v1/' + self.session.project_id + '/services/' + service_id
        auth_by_APIG(self.session.access_key, self.session.secret_key, 'DELETE', self.session.host, request_url, '')


class PredictorApiROMAImpl(PredictorApiBase):
    """ Make prediction requests to a ROMA ModelArts model service endpoint
    """

    def __init__(self, session, service_id):
        """ Initialize Predictor
        :param session: Building interactions with HUAWEI Cloud Service, including project id.
        :param service_id: The deployed model service id
        """
        PredictorApiBase.__init__(self)
        self.session = session
        self.service_id = service_id
        self.base_request_url = self.session.host + '/v1/' + self.session.project_id + '/services/'

    def get_service_info(self, service_id=None):
        """
        :param service_id: service id
        :return: service information
        """
        if service_id is None:
            service_id = self.service_id
        request_url = self.base_request_url + service_id
        return auth_by_roma_api(session=self.session, request_url=request_url, request_type=constant.HTTPS_GET,
                                intf_action="get_service_info")

    def predict(self, data, data_type):
        """
        :param data: Input data for which you want the model to provide inference.
        :param data_type: support {files, images}
        :return: predict result
        """
        predict_url = self.get_service_info()["access_address"]
        predict_file = {data_type: open(data, 'rb')}
        predict_body, Content_Type = requests.models.RequestEncodingMixin._encode_files(predict_file, {})
        self.session.headers['content-type'] = Content_Type
        self.session.headers['csb-token'] = self.session.headers['App-Token']
        model_create_resp = auth_by_roma_api(session=self.session, request_url=predict_url,
                                             request_type=constant.HTTPS_POST, intf_action="service predict",
                                             data=predict_body)
        predict_file[data_type].close()
        if not model_create_resp['success']:
            raise Exception("service predict failed, %s." % model_create_resp)
        return model_create_resp

    def get_service_list(self, **kwargs):
        """
        :param kwargs: index params
        :return: User service list
        """
        return auth_by_roma_api(session=self.session, request_url=self.base_request_url,
                                request_type=constant.HTTPS_GET, intf_action="get_service_list", params=None)

    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        raise Exception(" The ROMA ModelArts does not support edge service.")

    def update_service_config(self, service_id=None, **config_body):
        """update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        service_config_body = config_body
        if 'configs' in config_body:
            service_config_body['config'] = PredictorApiBase.convert_config_format(
                config_body['configs'])

        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id
        body = json.loads(json.dumps(str(service_config_body).replace("\'", "\"")))

        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_PUT, intf_action="update_service_config", data=body)

    def get_service_monitor(self, service_id=None, node_id=None):
        """  service monitor information
        :param service_id: service id
        :param node_id: node id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        query = {}
        if node_id:
            query['node_id'] = node_id
        request_url = self.base_request_url + service_id + '/monitor'
        return auth_by_roma_api(session=self.session, request_url=request_url, request_type=constant.HTTPS_GET,
                                intf_action="get_service_monitor")

    def get_service_logs(self, service_id=None):
        """
        :param service_id:  service id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id + '/logs'
        return auth_by_roma_api(session=self.session, request_url=request_url, request_type=constant.HTTPS_GET,
                                intf_action="get_service_logs")

    def delete_service(self, service_id):
        """ Delete a service
        :param service_id: service id
        """
        request_url = self.base_request_url + service_id
        auth_by_roma_api(session=self.session, request_url=request_url, request_type=constant.HTTPS_DELETE,
                         intf_action="delete_service")

